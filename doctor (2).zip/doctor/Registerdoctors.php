    
<?php

include("masterpages\Userheader.php");

echo '<script type="text/javascript" src="CSS/validation.js"></script>';
?>

 	<form name="frmregister" method="post" action="insertdoctor.php">
            
 				<table class="minitable">
				<tr>
				<td style="width:40%">
					Doctor Name:
                </td>
				<td>
					<input type="text" name="txtdoctorname" class="textbox_style" />
             	</td>
			</tr>
			<tr>
				<td>
					Sex:
                 </td>
			 <td>		
				<select name="cmbsex" class="lst_style">
        				<option value="Male">Male</option>
                        <option value="Female">Female</option>
       			</select>
            </td>
		</tr>
        <tr>
				<td>
					Address:
                </td>
				<td>
					<input type="text" name="txtaddress" class="textbox_style" />
             	</td>
			</tr>
            
          <tr>
          	<td>District</td>
            <td> 
            <select name="cmddistrict" class="lst_style">
        		    <option value="0">Select</option>
      				<?php
	 		 			include("./DB/config.php");
					   	$sql = "SELECT * FROM tbldistricts";
    	   				$query_result = mysql_query($sql);
					   	while($result = mysql_fetch_assoc($query_result))
        				{
	  			       		?>
				            <option value = "<?php echo $result['districts']?>"><?php echo $result['districts'] ?></option>
                                                        
        				<?php
        		
							}
					
						?>
        	</select>
            </td>
            
             <tr>
                	<td>Phone No:</td>
					<td><input type="text" name="txtphoneno" class="textbox_style" maxlength="15"/></td>
                </tr>
               
            
             <tr>
                	<td>Mobile No:</td>
					<td><input type="text" name="txtmobileno" class="textbox_style" maxlength="15"/></td>
                </tr>
               
               
               </tr>
                
                  <tr>
                	<td>Email Id:</td>
					<td><input type="text" name="txtemailid" class="textbox_style" maxlength="100"/></td>
                </tr>
                
                </tr>
                
                  <tr>
                	<td>Education:</td>
					<td><input type="text" name="txteducation" class="textbox_style" maxlength="100"/></td>
                </tr>
                
                  <tr>
                	<td>Speciality:</td>
					<td><input type="text" name="txtspeciality" class="textbox_style" maxlength="100"/></td>
                </tr>
                
                  <tr>
                	<td>Service At:</td>
					<td><input type="text" name="txtserviceat" class="textbox_style" maxlength="100"/></td>
                </tr>
                
                  <tr>
                	<td>Designation:</td>
					<td><input type="text" name="txtdesignation" class="textbox_style" maxlength="100"/></td>
                </tr>
                
                  <tr>
                	<td>Service Address:</td>
					<td><input type="text" name="txtserviceaddress" class="textbox_style" maxlength="100"/></td>
                </tr>
                
                
          </tr>
	    <tr>
			<td style="text-align:center;"> 
				<INPUT type="submit" name="btnregister" onclick="return check(frmregister)" value="Register" class="button_style">
                </td>
       
       <td> <button type="button" name="btnadd" class="button_style" onClick="window.location.href='Login.php'">Cancel</button></td>
      
       </tr>
      
            </table>
           
           </form>
                


<?php
include("masterpages\Footer.php");

?>


 <script language="javascript">
function check(f)
{
if(f.txtdoctorname.value=="")
{
   alert("This Name field can not be Empty");
   f.txtdoctorname.focus();
   return false ;
}
else if(f.txtaddress.value=="")
{
   alert("This address field can not be Empty");
   f.txtaddress.focus();
   return false ;
}
else if (f.txtphoneno.value=="" || checkphone(f.txtphoneno)==false)
{
   alert("This Phone No field can not be Empty");
   f.txtphoneno.focus();
   return false ;
}
else if (f.txtmobileno.value=="" || checkmobile(f.txtmobileno)==false)
{
   alert("This Mobile No field can not be Empty");
   f.txtmobileno.focus();
   return false ;
}
else if (f.txtemailid.value=="" || checkemail(f.txtemailid)==false)
{
   alert("This Email Id field can not be Empty");
   f.txtemailid.focus();
   return false ;
}

else if(f.txteducation.value=="")
{
	alert("The Education field can not be Empty");
	f.txteducation.focus();
	return false ;
}
else if(f.txtspeciality.value=="")
{
    alert("The Speciality cannot be empty");
    f.txtspeciality.focus();
    return false ;
}

}
</script>