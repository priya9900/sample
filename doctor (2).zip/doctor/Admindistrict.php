<?php
include("masterpages\Adminheader.php");

?>

<h1>List of Districts</h1>

<?php
 	include("./DB/config.php");
    $result = mysql_query("SELECT * FROM tbldistricts");
?>
	 <table class="gridview">
     <?php   
	 echo"<tr><th>ID</th>";
 	 echo"<th> Districts </th>";
	 echo"<th> Delete</th>";
	 
while($row = mysql_fetch_array($result))
  {
     echo "<tr>";
	 echo "<td>".$row['id']."</td>";
	 echo "<td>".$row['districts']."</td>";
	 echo "<td><a href=\"Admindeletedistricts.php?id=".$row['id']."\">Delete</a></td>";
     echo "</tr>";
  }
?>
   </table>
   
   <button type="button" name="btnadd" class="button_style" onClick="window.location.href='Adminadddistricts.php'">Add New</button>
   	

       

<?php
include("masterpages\Footer.php");

?>
