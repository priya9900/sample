<?php
include("masterpages\Adminheader.php");

?>

<center>

<h3>Information Message</h3>

<?php
      		$districts=$_POST['txtdistrict'];
			
	    	include("./DB/config.php");
	   		
			 $sql="INSERT INTO tbldistricts(districts) VALUES ('$districts')";

			 mysql_query($sql);
 			 
			 if(!$sql)
         	{
            	die("Database query failed: ". mysql_error());
        	}
	   ?>
      
    
     District is inserted to Database Successfully.
      
<br />
<a href="Admindistrict.php"><img src="images/back.jpg" /></a>
    
</center>
      

<?php
include("masterpages\Footer.php");

?>
