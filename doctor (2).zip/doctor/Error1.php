<?php
include("masterpages\Userheader.php");

?>
<center>
   Invalid Username or Password!
  <a href=Login.php>
         <img src='images/back.jpg' align='middle'></a></center>
				
                    

<?php
include("masterpages\Footer.php");

?>

