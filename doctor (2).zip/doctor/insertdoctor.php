<?php
include("masterpages\Userheader.php");

?>

<center>

<h3>Information Message</h3>

<?php
      		 include("./DB/config.php");
    
	$doctorname=$_POST['txtdoctorname'];
	$sex=$_POST['cmbsex'];
	$address=$_POST['txtaddress'];
	$district=$_POST['cmddistrict'];
	$phoneno=$_POST['txtphoneno'];
	$mobile=$_POST['txtmobileno']; 
    $emailid=$_POST['txtemailid'];
	$education=$_POST['txteducation'];
	$speciality=$_POST['txtspeciality'];
	$serviceat=$_POST['txtserviceat'];
	$designation=$_POST['txtdesignation'];
	$serviceaddress=$_POST['txtserviceaddress']; 

	
			 $sql="INSERT INTO tbldoctors(doctorname,sex,address,district,phoneno,mobile,emailid,education,speciality,serviceat,designation,serviceaddress,status) VALUES ('$doctorname','$sex','$address','$district','$phoneno','$mobile','$emailid','$education','$speciality','$serviceat','$designation','$serviceaddress','New')";

			 mysql_query($sql);
 			 
			 if(!$sql)
         	{
            	die("Database query failed: ". mysql_error());
        	}
	   ?>
      
    
     Doctors is inserted to Database Successfully.
      
<br />
<a href="Login.php"><img src="images/back.jpg" /></a>
    
</center>
      

<?php
include("masterpages\Footer.php");

?>
