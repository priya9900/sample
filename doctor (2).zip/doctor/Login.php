    
<?php
include("masterpages\Userheader.php");

?>

 	<form name="frmlogin" method="post" action="check_login.php">
            
 				<table class="minitable">
				<tr>
				<td style="width:40%">
						User name
                </td>
				<td>
					<input type="text" name="txtusername" class="textbox_style" />
             	</td>
			</tr>
			<tr>
				<td>
					Password
                 </td>
			 <td>		
					<input type="password" name="txtpassword" class="textbox_style"/>
            </td>
		</tr>
	    <tr>
			<td colspan="2" style="text-align:center;"> 
				<INPUT type="submit" name="btnlogin" onclick="return check(frmlogin)" value="Login" class="button_style">
                </td>
    		
       </tr>
       
       <tr>
       
       <td> <button type="button" name="btnadd" class="button_style" onClick="window.location.href='Registerdoctors.php'">Register Doctors</button></td>
       <td> <button type="button" name="btnadd" class="button_style" onClick="window.location.href='Registerhospitals.php'">Register Hospitals</button></td>
       </tr>
      
            </table>
           
           </form>
                


<?php
include("masterpages\Footer.php");

?>


 <script language="javascript">
function check(f)
{
str=document.frmlogin.txtusername.value;
str1=document.frmlogin.txtpassword.value;
if(str=="")
{
alert("This username field can not be empty");

f.txtusername.focus();

return false ;
}
else if (str1=="")
{
alert("This password field can not be empty");
f.txtpassword.focus();
return false ;

}
}



</script>
