<?php
session_start();
if(isset($_GET['cmddistrict']))
  {
  $_SESSION['districts']=$_GET['cmddistrict'];
  }
  if(isset($_GET['cmbstatus']))
  {
  $_SESSION['status']=$_GET['cmbstatus'];
  }
?>

<?php
include("masterpages\Adminheader.php");

?>

 
 <h3>Hospitals List</h3>

 <form name="frmsearch" method="get" action="">
        		<table class="minitable">
                <tr>
                <td>
              District 
              </td>
              <td> <select name="cmddistrict" class="lst_style">
        		    <option value="0">Select</option>
      				<?php
	 		 			include("./DB/config.php");
					   	$sql = "SELECT * FROM tbldistricts";
    	   				$query_result = mysql_query($sql);
					   	while($result = mysql_fetch_assoc($query_result))
        				{
	  			       		?>
				            <option value = "<?php echo $result['districts']?>"> <?php echo $result['districts'] ?> </option>
                                                        
        				<?php
        		
							}
					
						?>
        	</select>
            </td>
            </tr>
            
               <tr>
                <td>
              Status 
              </td>
              <td>
               <select name="cmbstatus" class="lst_style">
        <option value="Select" >Select
        </option>
        <option  value="New">New
        </option>
           <option value="Accepted">Accepted			 			</option>
        </select>
              </td>
              </tr>
              
              <tr>
              <td colspan="2">
            <input type="submit" name="btnsearch" value="Search" class="button_style"/>
            </td>
            </tr>
            </table>
            </form>
              
<?php
if(isset($_GET['cmddistrict']))
			{
	 			if($_GET['cmddistrict'] != "0")
				{
				$bg = $_GET["cmddistrict"];
				$status = $_GET["cmbstatus"];
				
 	include("./DB/config.php");
    $result = mysql_query("SELECT * FROM  tblhospitals where district='$bg' and status='$status'");
?>
	 <table class="gridview">
     <?php   
	 echo"<tr><th>Hospital Name</th>";
 	 echo"<th> District </th>";
	 echo"<th> Mobile</th>";
	 echo"<th> Services</th>";
	 echo"<th> More Info</th></tr>";
	 
while($row = mysql_fetch_array($result))
  {
     echo "<tr>";
	 echo "<td>".$row['hospitalname']."</td>";
	 echo "<td>".$row['district']."</td>";
	 echo "<td>".$row['mobileno']."</td>";
	 echo "<td>".$row['services']."</td>";
	 echo "<td><a href=\"Adminviewhospital.php?id=".$row['id']."\">View</a></td>";
     echo "</tr>";
  }
  
  }
  }
?>
   </table>
   
  
<?php
include("masterpages\Footer.php");

?>