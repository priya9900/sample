<?php
session_start();
if(isset($_GET['cmddistrict']))
  {
  $_SESSION['districts']=$_GET['cmddistrict'];
  }
  
  if(isset($_GET['txtspeciality']))
  {
  $_SESSION['speciality']=$_GET['txtspeciality'];
  }
?>

<?php
include("masterpages\Userheader.php");

?>

 
 <h3>Doctors List</h3>

 <form name="frmsearch" method="get" action="">
        	
            <table class="minitable">
            <tr>
            <td>
            	
              District </td>
              <td> <select name="cmddistrict" class="lst_style">
        		    <option value="0">Select</option>
      				<?php
	 		 			include("./DB/config.php");
					   	$sql = "SELECT * FROM tbldistricts";
    	   				$query_result = mysql_query($sql);
					   	while($result = mysql_fetch_assoc($query_result))
        				{
	  			       		?>
				            <option <?php echo (isset($_SESSION['districts']) ? (($_SESSION['districts']== $result['districts']) ? "Selected" : "") : "")  ?> value = "<?php echo $result['districts']?>"><?php echo $result['districts'] ?></option>
                                                        
        				<?php
        		
							}
					
						?>
        	</select>
            </td>
            </tr>
            <tr>
            <td>
            Speciality
            </td>
            <td>
            	<input name="txtspeciality" type="text" class="textbox_style" value="<?php echo (isset($_SESSION['speciality']) ? (($_SESSION['speciality']!="") ?  $_SESSION['speciality']: "") : "")  ?>"/> 
            </td>
            </tr>
            
            <tr>
            <td colspan="2">
            <input type="submit" name="btnsearch" value="Search" class="button_style"/>
            </td>
            </tr>
            
            </form>
              
<?php
if(isset($_GET['cmddistrict']))
			{
	 			if($_GET['cmddistrict'] != "0")
				{
				$bg = $_GET["cmddistrict"];
				$sp = $_GET['txtspeciality'];
 	include("./DB/config.php");
    $result = mysql_query("SELECT * FROM  tbldoctors where district='$bg' and status='Accepted' and speciality LIKE '%$sp%'");
?>
	 <table class="gridview">
     <?php   
	 echo"<tr><th>Doctors Name</th>";
 	 echo"<th> District </th>";
	 echo"<th> Mobile</th>";
	 echo"<th> Education</th>";
	 echo"<th> Speciality</th>";
	 echo"<th> More Info</th></tr>";
	 
while($row = mysql_fetch_array($result))
  {
     echo "<tr>";
	 echo "<td>".$row['doctorname']."</td>";
	 echo "<td>".$row['district']."</td>";
	 echo "<td>".$row['mobile']."</td>";
	 echo "<td>".$row['education']."</td>";
	 echo "<td>".$row['speciality']."</td>";
	 echo "<td><a href=\"Userviewdoctors.php?id=".$row['id']."\">View</a></td>";
     echo "</tr>";
  }
  
  }
  }
?>
   </table>
   
  
<?php
include("masterpages\Footer.php");

?>