<?php
include("masterpages\Userheader.php");

?>

<p>
aaaa<br />
D.S.A.T.M College.<br />
Banglore

</p>

<?php
include("masterpages\Footer.php");

?>