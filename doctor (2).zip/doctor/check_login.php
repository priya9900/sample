<?PHP
session_start();

$userid=$_POST['txtusername'];
$password=$_POST['txtpassword'];

$userid = addslashes($userid);
$password = addslashes($password);
include("./DB/Config.php");

$query = "SELECT * FROM tbllogin WHERE userid = '$userid' AND password = '$password'";

$results = mysql_query($query);

if(mysql_num_rows($results) <= 0)
 {
 
 		header('location:./Error1.php');
	  
		exit();
} 
else 
{

        $qu = "SELECT usertype FROM tbllogin WHERE userid = '$userid' AND password = '$password'";
        $res = mysql_query($qu);
   
        if ($row=mysql_fetch_array($res))
		{
		   $type=$row["usertype"];
		}
	
		  
        if ($type=="Admin")
		{
				session_start();
		        $_SESSION['memuser']=$userid;
		        $_SESSION['mempass']=$password;
		        $_SESSION['memtime']=time();
		
		        session_write_close();
		        header('location:./Adminhome.php');
		}
		
	exit();
	}
?>
