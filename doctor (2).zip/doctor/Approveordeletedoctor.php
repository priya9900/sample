

<?php
include("masterpages\Adminheader.php");

?>

<?php
$id=$_POST['txtid'];
include("./DB/config.php");
echo $id;
if(isset($_POST['btnapprove']))
{
$sql="Update tbldoctors set status='Accepted' where id=$id";
 mysql_query($sql);
 			 
			 if(!$sql)
         	{
            	die("Database query failed: ". mysql_error());
        	}
			else
			{
				echo "Approved Successfully";
				
				
				date_default_timezone_set('America/Toronto');

         require_once('PHPMailer_5.2.1\class.phpmailer.php');
         //include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

             $mail             = new PHPMailer();

              $msg              = "your Registration is Processed. Your Registration request is accepted.";
              $body             = $msg;
              //$body             = eregi_replace("[\]",'',$body);

              $mail->IsSMTP(); // telling the class to use SMTP
              $mail->Host       = "mail.gmail.com"; // SMTP server
              $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
              $mail->SMTPAuth   = true;                  // enable SMTP authentication
              $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
               $mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
              $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
                $mail->Username   = "kpkproject1@gmail.com";  // GMAIL username
               $mail->Password   = "ilovedvg";            // GMAIL password

              $mail->SetFrom($emailid, "Registration Processed");

                  //$mail->AddReplyTo("user2@gmail.com', 'First Last");

                $mail->Subject    = "Registration Processed";

                      //$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

                    $mail->MsgHTML($body);

                   $address =$emailid;
                  $mail->AddAddress($address, "user2");

                     //$mail->AddAttachment("images/phpmailer.gif");      // attachment
                         //$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment

            if(!$mail->Send())
			 {
                   echo "Mailer Error: " . $mail->ErrorInfo;
             } 
			 else 
			 {
                      echo "Message sent!";
              }
			}
}

else if(isset($_POST['btndelete']))
{
$sql="Delete from tbldoctors where id=$id";
 mysql_query($sql);
 			 
			 if(!$sql)
         	{
            	die("Database query failed: ". mysql_error());
        	}
			else
				echo "Deleted Successfully";
}

?>



<?php
include("masterpages\Footer.php");

?>