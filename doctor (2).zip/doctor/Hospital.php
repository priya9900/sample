<?php
session_start();
if(isset($_GET['cmddistrict']))
  {
  $_SESSION['districts']=$_GET['cmddistrict'];
  }
?>

<?php
include("masterpages\Userheader.php");

?>

 
 <h3>Hospital List</h3>

 <form name="frmsearch" method="get" action="">
        	
            <table class="minitable">
            <tr>
            <td>
            	
              District </td>
              <td> <select name="cmddistrict" class="lst_style">
        		    <option value="0">Select</option>
      				<?php
	 		 			include("./DB/config.php");
					   	$sql = "SELECT * FROM tbldistricts";
    	   				$query_result = mysql_query($sql);
					   	while($result = mysql_fetch_assoc($query_result))
        				{
	  			       		?>
				            <option <?php echo (isset($_SESSION['districts']) ? (($_SESSION['districts']== $result['districts']) ? "Selected" : "") : "")  ?> value = "<?php echo $result['districts']?>"><?php echo $result['districts'] ?></option>
                                                        
        				<?php
        		
							}
					
						?>
        	</select>
            </td>
            </tr>
         
            <tr>
            <td colspan="2">
            <input type="submit" name="btnsearch" value="Search" class="button_style"/>
            </td>
            </tr>
            
            </form>
              
<?php
if(isset($_GET['cmddistrict']))
			{
	 			if($_GET['cmddistrict'] != "0")
				{
				$bg = $_GET["cmddistrict"];
				//$sp = $_GET["txtspeciality"];
 	include("./DB/config.php");
    $result = mysql_query("SELECT * FROM  tblhospitals where district='$bg' and status='Accepted'");
?>
	 <table class="gridview">
     <?php   
	 echo"<tr><th>Hospital Name</th>";
 	 echo"<th> District </th>";
	 echo"<th> Mobile</th>";
	 echo"<th> Services</th>";
	 echo"<th> More Info</th></tr>";
	 
while($row = mysql_fetch_array($result))
  {
     echo "<tr>";
	 echo "<td>".$row['hospitalname']."</td>";
	 echo "<td>".$row['district']."</td>";
	 echo "<td>".$row['mobileno']."</td>";
	 echo "<td>".$row['services']."</td>";
	 echo "<td><a href=\"Userviewhospital.php?id=".$row['id']."\">View</a></td>";
     echo "</tr>";
  }
  
  }
  }
?>
   </table>
   
  
<?php
include("masterpages\Footer.php");

?>