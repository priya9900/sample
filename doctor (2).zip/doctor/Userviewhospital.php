

<?php
include("masterpages\Userheader.php");

?>


 <?php
				
 	include("./DB/config.php");
	$id=$_GET['id'];
    $result = mysql_query("SELECT * FROM  tblhospitals where id=$id");
	
	if($row = mysql_fetch_array($result))
	 {
	$hospitalname=$row['hospitalname'];
	$services=$row['services'];
	$address=$row['address'];
	$district=$row['district'];
	$phoneno=$row['phoneno'];
	$mobileno=$row['mobileno']; 
    $emailid=$row['emailid'];
	$features=$row['features'];
	 }
?>

<form name="frmregister" method="post" action="Approveordeletehospital.php">
            
 				<table class="minitable">
                
				<tr>
				<td style="width:40%">
					Hospital Name:
                </td>
				<td>
					<?php echo $hospitalname; ?>
             	</td>
			</tr>
			<tr>
				<td>
					Hospital Services:
                 </td>
			 <td>		
				<?php echo $services; ?>
            </td>
		</tr>
        <tr>
				<td>
					Hospital Address:
                </td>
				<td>
					<?php echo $address; ?>
             	</td>
			</tr>
            
          <tr>
          	<td>District</td>
            <td> 
            <?php echo $district; ?>
            </td>
            
             <tr>
                	<td>Phone No:</td>
					<td> <?php echo $phoneno; ?></td>
                </tr>
               
            
             <tr>
                	<td>Mobile No:</td>
					<td> <?php echo $mobileno; ?></td>
                </tr>
               
               
               </tr>
                
                  <tr>
                	<td>Email Id:</td>
					<td> <?php echo $emailid; ?></td>
                </tr>
                
                </tr>
                
                  <tr>
                	<td>Features:</td>
					<td> <?php echo $features; ?></td>
                </tr>
               
                
          </tr>
	    
       <tr>
       <td colspan="2" style="text-align:center;"> <button type="button" name="btnadd" class="button_style" onClick="window.location.href='Hospital.php'">Cancel</button></td>
      
       </tr>
      
            </table>
           
           </form>

<?php
include("masterpages\Footer.php");

?>