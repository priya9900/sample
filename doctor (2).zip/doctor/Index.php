    
<?php
include("masterpages\Userheader.php");

?>

  <p>
Doctors Dairy is a Doctors and Hospital based web portal and gate way of doctors and patient in Karnataka. Portal providing a basket of very useful services for Karnataka Doctors. In all the developed states, professionals have their own website. It helps them in many ways. Even in Karnataka, number of Doctors has developed their own website..</p>


<?php
include("masterpages\Footer.php");

?>