<?php
include("masterpages\Userheader.php");

?>

<center>

<h3>Information Message</h3>

<?php
      		 include("./DB/config.php");
    
	$hospitalname=$_POST['txthospitalname'];
	$services=$_POST['txtservices'];
	$address=$_POST['txtaddress'];
	$district=$_POST['cmddistrict'];
	$phoneno=$_POST['txtphoneno'];
	$mobileno=$_POST['txtmobileno']; 
    $emailid=$_POST['txtemailid'];
	$features=$_POST['txtfeatures'];

	
			 $sql="INSERT INTO tblhospitals(hospitalname,services,address,district,phoneno,mobileno,emailid,features,status) VALUES ('$hospitalname','$services','$address','$district','$phoneno','$mobileno','$emailid','$features','New')";

			 mysql_query($sql);
 			 
			 if(!$sql)
         	{
            	die("Database query failed: ". mysql_error());
        	}
	   ?>
      
    
     Doctors is inserted to Database Successfully.
      
<br />
<a href="Login.php"><img src="images/back.jpg" /></a>
    
</center>
      

<?php
include("masterpages\Footer.php");

?>
