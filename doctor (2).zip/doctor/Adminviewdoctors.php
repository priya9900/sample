

<?php
include("masterpages\Adminheader.php");

?>


 <?php
				
 	include("./DB/config.php");
	$id=$_GET['id'];
    $result = mysql_query("SELECT * FROM  tbldoctors where id=$id");
	
	if($row = mysql_fetch_array($result))
	 {
	  $id=$row['id'];
	 $doctorname=$row['doctorname'];
	$sex=$row['sex'];
	$address=$row['address'];
	$district=$row['district'];
	$phoneno=$row['phoneno'];
	$mobile=$row['mobile']; 
    $emailid=$row['emailid'];
	$education=$row['education'];
	$speciality=$row['speciality'];
	$serviceat=$row['serviceat'];
	$designation=$row['designation'];
	$serviceaddress=$row['serviceaddress']; 
	 }
?>

<form name="frmregister" method="post" action="Approveordeletedoctor.php">
            
 				<table class="minitable">
                <tr>
				<td style="width:40%">
					ID:
                </td>
				<td>
					<input type="text" name="txtid" class="textbox_style" value="<?php echo $id; ?>" readonly="readonly" />
             	</td>
			</tr>
            
				<tr>
				<td style="width:40%">
					Doctor Name:
                </td>
				<td>
					<?php echo $doctorname; ?>
             	</td>
			</tr>
			<tr>
				<td>
					Sex:
                 </td>
			 <td>		
				<?php echo $sex; ?>
            </td>
		</tr>
        <tr>
				<td>
					Address:
                </td>
				<td>
					<?php echo $address; ?>
             	</td>
			</tr>
            
          <tr>
          	<td>District</td>
            <td> 
            <?php echo $district; ?>
            </td>
            
             <tr>
                	<td>Phone No:</td>
					<td> <?php echo $phoneno; ?></td>
                </tr>
               
            
             <tr>
                	<td>Mobile No:</td>
					<td> <?php echo $mobile; ?></td>
                </tr>
               
               
               </tr>
                
                  <tr>
                	<td>Email Id:</td>
					<td> <?php echo $emailid; ?></td>
                </tr>
                
                </tr>
                
                  <tr>
                	<td>Education:</td>
					<td> <?php echo $education; ?></td>
                </tr>
                
                  <tr>
                	<td>Speciality:</td>
					<td> <?php echo $speciality; ?></td>
                </tr>
                
                  <tr>
                	<td>Service At:</td>
					<td> <?php echo $serviceat; ?></td>
                </tr>
                
                  <tr>
                	<td>Designation:</td>
					<td> <?php echo $designation; ?></td>
                </tr>
                
                  <tr>
                	<td>Service Address:</td>
					<td> <?php echo $serviceaddress; ?></td>
                </tr>
                
                
          </tr>
	    <tr>
			<td style="text-align:center;"> 
				<INPUT type="submit" name="btnapprove" value="Approve" class="button_style"></td>
                <td>
                	<INPUT type="submit" name="btndelete" value="Delete" class="button_style">
                </td>
       </tr>
       <tr>
       <td colspan="2" style="text-align:center;"> <button type="button" name="btnadd" class="button_style" onClick="window.location.href='Admindoctorslist.php'">Cancel</button></td>
      
       </tr>
      
            </table>
           
           </form>

<?php
include("masterpages\Footer.php");

?>