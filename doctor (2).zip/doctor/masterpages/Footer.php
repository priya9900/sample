﻿<?php
echo '</div><!-- end of section 1 -->
    <div class="cleaner_with_height">&nbsp;</div>
</div>


<div id="templatemo_footer_panel">
    | Designed by :PRIYANKA AND POOJA|</div>
</div> <!-- end of container -->

    </form>
</body>
</html>';
?>