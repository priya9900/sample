<?php

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 	<title>Doctors Dairy</title>
    <link href="CSS/templatemo_style.css" rel="stylesheet" type="text/css" />
     <link href="CSS/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="CSS/js-image-slider.js"type="text/javascript"></script>
    <link rel="Stylesheet" type="text/css" href="CSS/Control.css" />
</head>

<body>
 <div id="templatemo_container">
<div id="templatemo_top_panel">
	<div id="templatemo_header_section">
		<div id="templatemo_header">
        	Doctors Dairy
        </div>
    </div> <!-- end of header section -->
    
    <div id="templatemo_menu_login_section">
    	<div id="templatemo_menu_section">
        	<div id="templatemo_menu_panel">
                <ul>
                    <li><a href="Index.php">Home</a></li>
                    <li><a href="Doctors.php">Doctors</a></li>
                    <li><a href="Hospital.php">Hospitals</a></li>
                    <li><a href="Contactus.php">Contact Us</a></li>     
					<li><a href="Login.php">Login</a></li>  
                </ul> 
            </div> <!-- end of menu -->
        </div>
    </div> <!-- end of menu login section -->
</div> <!-- end of top panel -->


<div id="templatemo_content_panel_1">

	<div id="templatemo_news_section">
      
        <div id="sliderFrame">
       <div id="slider">
         <img src="images/Slide Images/1.png" alt="Doctors New Your Home." />
         <img src="images/Slide Images/2.png" alt="" />
         <img src="images/Slide Images/3.png" alt="" />
         <img src="images/Slide Images/4.png" alt="" />
          <img src="images/Slide Images/5.png" alt="" />
       </div>
   </div>';
 ?>