

<?php
include("masterpages\Adminheader.php");

?>

<?php
$id=$_POST['txtid'];
include("./DB/config.php");
echo $id;
if(isset($_POST['btnapprove']))
{
$sql="Update  tblhospitals set status='Accepted' where id=$id";
 mysql_query($sql);
 			 
			 if(!$sql)
         	{
            	die("Database query failed: ". mysql_error());
        	}
			else
			{
				echo "Approved Successfully";
			}
}

else if(isset($_POST['btndelete']))
{
$sql="Delete from tblhospitals where id=$id";
 mysql_query($sql);
 			 
			 if(!$sql)
         	{
            	die("Database query failed: ". mysql_error());
        	}
			else
				echo "Deleted Successfully";
}

?>



<?php
include("masterpages\Footer.php");

?>