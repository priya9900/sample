<?php
include("masterpages\Adminheader.php");

?>

<h1>Add Districts</h1>

<form name="frmadddistricts" action="insertdistricts.php" method="post">
	 <table class="minitable">
   		
         <tr>
            	<td>District</td>
                <td><input type="text" name="txtdistrict" class="textbox_style" maxlength="100"/></td>
            </tr>
                     
             <tr>
                <td colspan="2" style="text-align:center;">
                 <input type="submit" name="btnsave" value="Save" class="button_style" onclick="return check(frmadddistricts)" />
                 <button type="button" name="cancel" class="button_style" onClick="window.location.href='Admindistrict.php'">Cancel</button>
                </td>
            </tr>
     </table>
   </form>	
   

<?php
include("masterpages\Footer.php");

?>

<script type="text/javascript">
function check(f)
{
  if(f.txtdistrict.value=="")
   {
        alert("District cannot be empty");
        f.txtdistrict.focus();
		return false ;
    }
	else
		return true;

}
</script>