<?php
include("masterpages\Adminheader.php");

?>

<center>

<img src="images/welcome.gif" />

</center>

<?php
include("masterpages\Footer.php");

?>

