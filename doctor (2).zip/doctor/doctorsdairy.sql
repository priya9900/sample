-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2017 at 12:17 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctorsdairy`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbldistricts`
--

CREATE TABLE `tbldistricts` (
  `id` int(11) NOT NULL,
  `districts` varchar(100) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tbldistricts`
--

INSERT INTO `tbldistricts` (`id`, `districts`) VALUES
(2, 'Davangere'),
(5, 'bellary'),
(6, 'Bangalore'),
(7, 'Dhrwad'),
(8, 'Koppal'),
(9, 'Gulbarga');

-- --------------------------------------------------------

--
-- Table structure for table `tbldoctors`
--

CREATE TABLE `tbldoctors` (
  `id` int(11) NOT NULL,
  `doctorname` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `sex` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `district` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `phoneno` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `mobile` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `emailid` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `education` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `speciality` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `serviceat` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `designation` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `serviceaddress` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(50) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tbldoctors`
--

INSERT INTO `tbldoctors` (`id`, `doctorname`, `sex`, `address`, `district`, `phoneno`, `mobile`, `emailid`, `education`, `speciality`, `serviceat`, `designation`, `serviceaddress`, `status`) VALUES
(2, 'Anusha', 'Female', 'Vidyar Nagar, Harihar', 'Davangere', '08192-232323', '9087654321', 'anusha@gmail.com', 'M.B.B.S', 'General', 'Bapuji', 'Doctor', 'Bapuji, Davangere', 'Accepted'),
(3, 'Sowmya', 'Female', 'M.C.C A BloCk', 'Davangere', '08192-232323', '9087654321', 'sowmya@gmail.com', 'M.B.B.S', 'MD', 'Chigteri', 'Doctor', 'Chigateri', 'Accepted'),
(5, 'Damodar', 'Male', 'banglore', 'Davangere', '02598-777777', '9000123456', 'post@gmail.com', 'MBBS', 'eye', 'home', 'prop', 'hospet', 'New'),
(6, 'sai', 'Male', 'sandoor', 'bellary', '02598-777777', '2222222222', 'SDMC_care@gmail.com', 'MBBS', 'ENT', 'Hospet', 'SSS', 'Koppal', 'Accepted'),
(7, 'Damodar', 'Male', 'banglore', 'Bangalore', '99999-999999', '8888888888', 'Damodarbhat@gmail.com', 'MBBS', 'ENT', 'BANGALORE', 'BANGALORE', 'Banglore', 'Accepted'),
(8, 'siddesh', 'Male', 'Harohali', 'Bangalore', '08397-247895', '3625147895', 'SSSS@gmail.com', 'MBBS', 'Eye1', 'BANGALORE', 'Spealist', 'Banglore', 'New');

-- --------------------------------------------------------

--
-- Table structure for table `tblhospitals`
--

CREATE TABLE `tblhospitals` (
  `id` int(11) NOT NULL,
  `hospitalname` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `services` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `district` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `phoneno` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `mobileno` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `emailid` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `features` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(50) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tblhospitals`
--

INSERT INTO `tblhospitals` (`id`, `hospitalname`, `services`, `address`, `district`, `phoneno`, `mobileno`, `emailid`, `features`, `status`) VALUES
(3, 'Bapuji', 'All Treatments', 'M.C.C B Block', 'Davangere', '08192-212121', '9036925840', 'bapuji@gmail.com', 'Dtssss', 'Accepted'),
(4, 'Sagar', 'All Tretements', 'Banglore', 'Bangalore', '03458-986522', '6666666321', 'Sagar@gmail.com', 'All fearures', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `tbllogin`
--

CREATE TABLE `tbllogin` (
  `userid` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `usertype` varchar(50) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `tbllogin`
--

INSERT INTO `tbllogin` (`userid`, `password`, `usertype`) VALUES
('admin', 'admin', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbldistricts`
--
ALTER TABLE `tbldistricts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbldoctors`
--
ALTER TABLE `tbldoctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblhospitals`
--
ALTER TABLE `tblhospitals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbllogin`
--
ALTER TABLE `tbllogin`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbldistricts`
--
ALTER TABLE `tbldistricts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbldoctors`
--
ALTER TABLE `tbldoctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tblhospitals`
--
ALTER TABLE `tblhospitals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
