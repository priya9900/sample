<?php
session_start();
if(isset($_GET['cmddistrict']))
  {
  $_SESSION['districts']=$_GET['cmddistrict'];
  }
  if(isset($_GET['cmbstatus']))
  {
  $_SESSION['status']=$_GET['cmbstatus'];
  }
?>

<?php
include("masterpages\Adminheader.php");

?>

 
 <h3>Doctors List</h3>

 <form name="frmsearch" method="get" action="">
        		<table class="minitable">
                <tr>
                <td>
              District 
              </td>
              <td> <select name="cmddistrict" class="lst_style">
        		    <option value="0">Select</option>
      				<?php
	 		 			include("./DB/config.php");
					   	$sql = "SELECT * FROM tbldistricts";
    	   				$query_result = mysql_query($sql);
					   	while($result = mysql_fetch_assoc($query_result))
        				{
	  			       		?>
				            <option <?php echo (isset($_SESSION['districts']) ? (($_SESSION['districts']== $result['districts']) ? "Selected" : "") : "")  ?> value = "<?php echo $result['districts']?>"><?php echo $result['districts'] ?></option>
                                                        
        				<?php
        		
							}
					
						?>
        	</select>
            </td>
            </tr>
            
               <tr>
                <td>
              Status 
              </td>
              <td>
               <select name="cmbstatus" class="lst_style">
        <option <?php echo (isset($_SESSION['status']) ? (($_SESSION['status']=="Select") ? "Selected" : "") : "")  ?> value="Select" >Select
        </option>
        <option <?php echo (isset($_SESSION['status']) ? (($_SESSION['status']=="New") ? "Selected" : "") : "")  ?> value="New">New
        </option>
           <option <?php echo (isset($_SESSION['status']) ? (($_SESSION['status']=="Accepted") ? "Selected" : "") : "")  ?> value="Accepted">Accepted			 			</option>
        </select>
              </td>
              </tr>
              
              <tr>
              <td colspan="2">
            <input type="submit" name="btnsearch" value="Search" class="button_style"/>
            </td>
            </tr>
            </table>
            </form>
              
<?php
if(isset($_GET['cmddistrict']))
			{
	 			if($_GET['cmddistrict'] != "0")
				{
				$bg = $_GET["cmddistrict"];
				$status = $_GET["cmbstatus"];
				
 	include("./DB/config.php");
    $result = mysql_query("SELECT * FROM  tbldoctors where district='$bg' and status='$status'");
?>
	 <table class="gridview">
     <?php   
	 echo"<tr><th>Doctors Name</th>";
 	 echo"<th> District </th>";
	 echo"<th> Mobile</th>";
	 echo"<th> Education</th>";
	 echo"<th> Specialit</th>";
	 echo"<th> More Info</th></tr>";
	 
while($row = mysql_fetch_array($result))
  {
     echo "<tr>";
	 echo "<td>".$row['doctorname']."</td>";
	 echo "<td>".$row['district']."</td>";
	 echo "<td>".$row['mobile']."</td>";
	 echo "<td>".$row['education']."</td>";
	 echo "<td>".$row['speciality']."</td>";
	 echo "<td><a href=\"Adminviewdoctors.php?id=".$row['id']."\">View</a></td>";
     echo "</tr>";
  }
  
  }
  }
?>
   </table>
   
  
<?php
include("masterpages\Footer.php");

?>