<?php
include("masterpages\Adminheader.php");

?>

<center>

<h3>Information Message</h3>

<?php
      		$id=$_GET['id'];
			
	    	include("./DB/config.php");
	   		
			 $sql="Delete from tbldistricts where id=$id";

			 mysql_query($sql);
 			 
			 if(!$sql)
         	{
            	die("Database query failed: ". mysql_error());
        	}
	   ?>
      
    
     District is Deleted from Database Successfully.
      
<br />
<a href="Admindistrict.php"><img src="images/back.jpg" /></a>
    
</center>


<?php
include("masterpages\Footer.php");

?>
