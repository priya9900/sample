<?php
  $user="root";
  $host="localhost";
  $pwd="";
  $db="doctorsdairy";

  
mysql_connect($host, $user, $pwd) or die('Error, Connection to MySQL Server failed');
mysql_select_db ($db) or die('Error, Connection to database failed');

?>